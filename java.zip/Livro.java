import javax.swing.JOptionPane;
import java.util.ArrayList;

class Livro {
    public String titulo;
    protected String autor;
    private int anoPublicacao;

    public Livro(String titulo, String autor, int anoPublicacao) {
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicacao = anoPublicacao;
    }

    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    public void setAnoPublicacao(int anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public void exibirDetalhes() {
        String detalhes = "Título: " + titulo + "\n" +
                          "Autor: " + autor + "\n" +
                          "Ano de Publicação: " + anoPublicacao;
        JOptionPane.showMessageDialog(null, detalhes);
    }
}
