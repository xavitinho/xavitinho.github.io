import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Principal {
    private static ArrayList<Livro> livros = new ArrayList<>();

    public static void main(String[] args) {
        while (true) {
            String menu = "Menu:\n" +
                          "1. Adicionar Livro\n" +
                          "2. Listar Livros\n" +
                          "3. Sair\n" +
                          "Escolha uma opção:";
            String opcaoStr = JOptionPane.showInputDialog(menu);
            int opcao;

            try {
                opcao = Integer.parseInt(opcaoStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opção inválida! Tente novamente.");
                continue;
            }

            switch (opcao) {
                case 1:
                    adicionarLivro();
                    break;
                case 2:
                    listarLivros();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Saindo...");
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida! Tente novamente.");
            }
        }
    }

    private static void adicionarLivro() {
        String titulo = JOptionPane.showInputDialog("Digite o título do livro:");
        String autor = JOptionPane.showInputDialog("Digite o autor do livro:");
        String anoPublicacaoStr = JOptionPane.showInputDialog("Digite o ano de publicação do livro:");

        int anoPublicacao;
        try {
            anoPublicacao = Integer.parseInt(anoPublicacaoStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Ano de publicação inválido! Tente novamente.");
            return;
        }

        Livro novoLivro = new Livro(titulo, autor, anoPublicacao);
        livros.add(novoLivro);
        JOptionPane.showMessageDialog(null, "Livro adicionado com sucesso!");
    }

    private static void listarLivros() {
        if (livros.isEmpty()) {
            JOptionPane.showMessageDialog(null, "A biblioteca está vazia.");
        } else {
            StringBuilder lista = new StringBuilder("Livros na Biblioteca:\n");
            for (Livro livro : livros) {
                lista.append("Título: ").append(livro.titulo).append("\n")
                     .append("Autor: ").append(livro.autor).append("\n")
                     .append("Ano de Publicação: ").append(livro.getAnoPublicacao()).append("\n\n");
            }
            JOptionPane.showMessageDialog(null, lista.toString());
        }
    }
}